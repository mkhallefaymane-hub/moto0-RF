"use client"

import { useState } from "react"
import { Heart, MapPin, Gauge, Calendar, Fuel, ChevronRight, ChevronLeft, MessageSquare, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/language-context"

export function ListingsGrid() {
  const { t, dir, formatPrice } = useLanguage()
  const [savedIds, setSavedIds] = useState<number[]>([])
  const ArrowIcon = dir === "rtl" ? ChevronLeft : ChevronRight

  const listings = [
    {
      id: 1,
      image: "/silver-dacia-sandero-2019-morocco-urban-setting.jpg",
      titleFr: "Dacia Sandero",
      titleAr: "داسيا سانديرو",
      subtitleFr: "Stepway",
      subtitleAr: "ستيبواي",
      price: 95000,
      locationFr: "Casablanca",
      locationAr: "الدار البيضاء",
      mileageFr: "78 000 km",
      mileageAr: "78.000 كم",
      year: "2019",
      fuelFr: "Essence",
      fuelAr: "بنزين",
      badgeFr: "Très bon état",
      badgeAr: "حالة ممتازة",
      badgeType: "Premium",
      isNew: false,
      isSold: false,
    },
    {
      id: 2,
      image: "/grey-renault-megane-2017-morocco-parking.jpg",
      titleFr: "Renault Mégane",
      titleAr: "رينو ميغان",
      subtitleFr: "1.5 dCi",
      subtitleAr: "1.5 dCi",
      price: 115000,
      locationFr: "Rabat",
      locationAr: "الرباط",
      mileageFr: "142 000 km",
      mileageAr: "142.000 كم",
      year: "2017",
      fuelFr: "Diesel",
      fuelAr: "ديزل",
      badgeFr: "Vérifié",
      badgeAr: "موثق",
      badgeType: "Verified",
      isNew: false,
      isSold: false,
    },
    {
      id: 3,
      image: "/white-peugeot-308-2020-morocco-street.jpg",
      titleFr: "Peugeot 308",
      titleAr: "بيجو 308",
      subtitleFr: "Active",
      subtitleAr: "أكتيف",
      price: 165000,
      locationFr: "Marrakech",
      locationAr: "مراكش",
      mileageFr: "45 000 km",
      mileageAr: "45.000 كم",
      year: "2020",
      fuelFr: "Essence",
      fuelAr: "بنزين",
      badgeFr: "Nouvelle annonce",
      badgeAr: "إعلان جديد",
      badgeType: "New Arrival",
      isNew: true,
      isSold: false,
    },
    {
      id: 4,
      image: "/blue-hyundai-i20-2018-morocco-city.jpg",
      titleFr: "Hyundai i20",
      titleAr: "هيونداي i20",
      subtitleFr: "Premium",
      subtitleAr: "بريميوم",
      price: 89000,
      locationFr: "Fès",
      locationAr: "فاس",
      mileageFr: "95 000 km",
      mileageAr: "95.000 كم",
      year: "2018",
      fuelFr: "Essence",
      fuelAr: "بنزين",
      badgeFr: "Enchère",
      badgeAr: "مزاد",
      badgeType: "Auction",
      isNew: false,
      isSold: false,
    },
    {
      id: 5,
      image: "/black-volkswagen-golf-2016-morocco-street-parking.jpg",
      titleFr: "Volkswagen Golf",
      titleAr: "فولكسفاغن غولف",
      subtitleFr: "VII 1.6 TDI",
      subtitleAr: "VII 1.6 TDI",
      price: 135000,
      locationFr: "Tanger",
      locationAr: "طنجة",
      mileageFr: "168 000 km",
      mileageAr: "168.000 كم",
      year: "2016",
      fuelFr: "Diesel",
      fuelAr: "ديزل",
      badgeFr: "À la une",
      badgeAr: "مميز",
      badgeType: "Featured",
      isNew: false,
      isSold: true, // This one is sold
    },
    {
      id: 6,
      image: "/red-honda-sh-125-scooter-morocco-urban.jpg",
      titleFr: "Honda SH 125",
      titleAr: "هوندا SH 125",
      subtitleFr: "Scooter",
      subtitleAr: "سكوتر",
      price: 28000,
      locationFr: "Agadir",
      locationAr: "أكادير",
      mileageFr: "12 000 km",
      mileageAr: "12.000 كم",
      year: "2021",
      fuelFr: "Essence",
      fuelAr: "بنزين",
      badgeFr: "Moto",
      badgeAr: "دراجة نارية",
      badgeType: "Moto",
      isNew: true,
      isSold: false,
    },
  ]

  const getBadgeVariant = (badge: string) => {
    switch (badge) {
      case "Premium":
        return "bg-accent text-accent-foreground"
      case "Verified":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
      case "New Arrival":
        return "bg-blue-500/20 text-blue-400 border-blue-500/30"
      case "Auction":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      case "Featured":
        return "bg-amber-500/20 text-amber-400 border-amber-500/30"
      case "Moto":
        return "bg-green-500/20 text-green-400 border-green-500/30"
      default:
        return "bg-secondary text-secondary-foreground"
    }
  }

  const toggleSave = (id: number) => {
    setSavedIds((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]))
  }

  return (
    <section className="py-12 lg:py-20 bg-secondary/30" dir={dir}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-3xl lg:text-5xl font-black tracking-tight text-foreground mb-2">
              {t("Dernières annonces", "أحدث الإعلانات")}
              <span className="text-accent">.</span>
            </h2>
            <p className="text-muted-foreground">
              {t("Nouvelles arrivées de vendeurs vérifiés", "وصول جديد من بائعين موثوقين")}
            </p>
          </div>
          <Button variant="ghost" className="text-muted-foreground hover:text-foreground font-semibold hidden sm:flex">
            {t("Voir toutes les annonces", "عرض جميع الإعلانات")}
            <ArrowIcon className={`${dir === "rtl" ? "mr-1" : "ml-1"} h-4 w-4`} />
          </Button>
        </div>

        {/* Listings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {listings.map((listing) => (
            <div
              key={listing.id}
              className={`group bg-card rounded-2xl overflow-hidden border border-border hover:border-accent/50 transition-all duration-300 relative ${listing.isSold ? "opacity-75" : ""}`}
            >
              {listing.isSold && (
                <div className="absolute inset-0 z-20 pointer-events-none">
                  <div
                    className={`absolute ${dir === "rtl" ? "-left-12" : "-right-12"} top-8 ${dir === "rtl" ? "rotate-[-45deg]" : "rotate-45"} bg-red-600 text-foreground text-sm font-black py-2 px-16`}
                  >
                    {t("VENDU", "مباع")}
                  </div>
                </div>
              )}

              {/* Image Container */}
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={listing.image || "/placeholder.svg"}
                  alt={t(listing.titleFr, listing.titleAr)}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />

                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-card/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                {/* Badge */}
                <div className={`absolute top-3 ${dir === "rtl" ? "right-3" : "left-3"}`}>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold border ${getBadgeVariant(listing.badgeType)}`}
                  >
                    {t(listing.badgeFr, listing.badgeAr)}
                  </span>
                </div>

                {/* Save Button */}
                <button
                  onClick={() => toggleSave(listing.id)}
                  className={`absolute top-3 ${dir === "rtl" ? "left-3" : "right-3"} w-10 h-10 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center transition-transform hover:scale-110`}
                >
                  <Heart
                    className={`h-5 w-5 transition-colors ${
                      savedIds.includes(listing.id) ? "text-red-500 fill-red-500" : "text-foreground"
                    }`}
                  />
                </button>

                {/* New Badge */}
                {listing.isNew && !listing.isSold && (
                  <div
                    className={`absolute bottom-3 ${dir === "rtl" ? "right-3" : "left-3"} px-2 py-1 bg-foreground text-background text-xs font-bold rounded`}
                  >
                    {t("NOUVEAU", "جديد")}
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-5">
                {/* Title & Price */}
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div>
                    <h3 className="text-lg font-bold text-foreground group-hover:text-accent transition-colors">
                      {t(listing.titleFr, listing.titleAr)}
                    </h3>
                    <p className="text-sm text-muted-foreground">{t(listing.subtitleFr, listing.subtitleAr)}</p>
                  </div>
                  <p className="text-xl font-black text-accent whitespace-nowrap">{formatPrice(listing.price)}</p>
                </div>

                {/* Specs */}
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 flex-shrink-0" />
                    <span className="truncate">{t(listing.locationFr, listing.locationAr)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Gauge className="h-4 w-4 flex-shrink-0" />
                    <span>{t(listing.mileageFr, listing.mileageAr)}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 flex-shrink-0" />
                    <span>{listing.year}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Fuel className="h-4 w-4 flex-shrink-0" />
                    <span>{t(listing.fuelFr, listing.fuelAr)}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 mb-4 text-xs text-muted-foreground">
                  <Check className="h-3 w-3 text-green-500" />
                  <span>{t("Immatriculation marocaine", "ترقيم مغربي")}</span>
                </div>

                {/* CTA - WhatsApp or sold message */}
                {listing.isSold ? (
                  <Button
                    disabled
                    className="w-full bg-secondary/50 text-muted-foreground font-semibold cursor-not-allowed"
                  >
                    {t("Annonce vendue", "الإعلان مباع")}
                  </Button>
                ) : (
                  <Button className="w-full bg-green-600 hover:bg-green-700 text-foreground font-semibold">
                    <MessageSquare className={`h-4 w-4 ${dir === "rtl" ? "ml-2" : "mr-2"}`} />
                    {t("Contacter sur WhatsApp", "التواصل عبر واتساب")}
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Mobile View All */}
        <div className="mt-8 sm:hidden">
          <Button className="w-full bg-foreground text-background hover:bg-foreground/90 font-semibold h-12">
            {t("Voir toutes les annonces", "عرض جميع الإعلانات")}
            <ArrowIcon className={`${dir === "rtl" ? "mr-1" : "ml-1"} h-4 w-4`} />
          </Button>
        </div>
      </div>
    </section>
  )
}
