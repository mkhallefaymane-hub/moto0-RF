"use client"

import { useState } from "react"
import { Play, Heart, MessageCircle, Share2, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLanguage } from "@/lib/language-context"

export function FeaturedReels() {
  const { t, dir, formatPrice } = useLanguage()
  const [hoveredId, setHoveredId] = useState<number | null>(null)
  const [likedIds, setLikedIds] = useState<number[]>([])

  const reels = [
    {
      id: 1,
      thumbnail: "/white-dacia-logan-2018-parked-in-casablanca-street.jpg",
      titleFr: "Dacia Logan",
      titleAr: "داسيا لوغان",
      seller: "@casa_auto",
      likes: "1.2K",
      comments: "89",
      price: 85000,
      year: "2018",
      cityFr: "Casablanca",
      cityAr: "الدار البيضاء",
    },
    {
      id: 2,
      thumbnail: "/grey-renault-clio-2019-parked-urban-morocco.jpg",
      titleFr: "Renault Clio",
      titleAr: "رينو كليو",
      seller: "@rabat_motors",
      likes: "890",
      comments: "56",
      price: 115000,
      year: "2019",
      cityFr: "Rabat",
      cityAr: "الرباط",
    },
    {
      id: 3,
      thumbnail: "/blue-peugeot-208-2020-morocco-city-background.jpg",
      titleFr: "Peugeot 208",
      titleAr: "بيجو 208",
      seller: "@marrakech_cars",
      likes: "2.1K",
      comments: "134",
      price: 145000,
      year: "2020",
      cityFr: "Marrakech",
      cityAr: "مراكش",
    },
    {
      id: 4,
      thumbnail: "/red-volkswagen-golf-2017-morocco-parking-lot.jpg",
      titleFr: "Volkswagen Golf",
      titleAr: "فولكسفاغن غولف",
      seller: "@tanger_auto",
      likes: "1.8K",
      comments: "98",
      price: 125000,
      year: "2017",
      cityFr: "Tanger",
      cityAr: "طنجة",
    },
  ]

  const toggleLike = (id: number) => {
    setLikedIds((prev) => (prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]))
  }

  return (
    <section className="py-12 lg:py-20 bg-background" dir={dir}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-3xl lg:text-5xl font-black tracking-tight text-foreground mb-2">
              {t("Tendances", "الأكثر رواجاً")}
              <span className="text-accent">.</span>
            </h2>
            <p className="text-muted-foreground">{t("Les plus vues cette semaine", "الأكثر مشاهدة هذا الأسبوع")}</p>
          </div>
          <Button variant="ghost" className="text-muted-foreground hover:text-foreground font-semibold">
            {t("Voir tout", "عرض الكل")}
          </Button>
        </div>

        {/* Reels Grid - Instagram Style */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {reels.map((reel) => (
            <div
              key={reel.id}
              className="relative aspect-[3/4] rounded-2xl overflow-hidden group cursor-pointer"
              onMouseEnter={() => setHoveredId(reel.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              {/* Thumbnail */}
              <img
                src={reel.thumbnail || "/placeholder.svg"}
                alt={t(reel.titleFr, reel.titleAr)}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />

              {/* Play Button */}
              <div
                className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${
                  hoveredId === reel.id ? "opacity-100" : "opacity-0"
                }`}
              >
                <div className="w-16 h-16 rounded-full bg-foreground/90 flex items-center justify-center">
                  <Play className={`h-6 w-6 text-background ${dir === "rtl" ? "mr-1" : "ml-1"}`} fill="currentColor" />
                </div>
              </div>

              {/* Side Actions */}
              <div
                className={`absolute ${dir === "rtl" ? "left-3" : "right-3"} bottom-24 flex flex-col items-center gap-4`}
              >
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleLike(reel.id)
                  }}
                  className="flex flex-col items-center gap-1"
                >
                  <Heart
                    className={`h-6 w-6 transition-colors ${
                      likedIds.includes(reel.id) ? "text-red-500 fill-red-500" : "text-foreground"
                    }`}
                  />
                  <span className="text-xs font-semibold text-foreground">{reel.likes}</span>
                </button>
                <button className="flex flex-col items-center gap-1">
                  <MessageCircle className="h-6 w-6 text-foreground" />
                  <span className="text-xs font-semibold text-foreground">{reel.comments}</span>
                </button>
                <button className="flex flex-col items-center gap-1">
                  <Share2 className="h-5 w-5 text-foreground" />
                </button>
              </div>

              {/* Bottom Info */}
              <div className={`absolute bottom-0 ${dir === "rtl" ? "right-0 left-0" : "left-0 right-0"} p-4`}>
                <p className="text-xs text-muted-foreground mb-1">{reel.seller}</p>
                <h3 className="text-base lg:text-lg font-bold text-foreground mb-1">{t(reel.titleFr, reel.titleAr)}</h3>
                <div className="flex items-center gap-2">
                  <span className="text-accent font-black">{formatPrice(reel.price)}</span>
                  <span className="text-xs text-muted-foreground">• {reel.year}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{t(reel.cityFr, reel.cityAr)}</p>
              </div>

              {/* WhatsApp Badge for first reel */}
              {reel.id === 1 && (
                <div
                  className={`absolute top-3 ${dir === "rtl" ? "right-3" : "left-3"} flex items-center gap-1.5 px-2 py-1 bg-green-600 rounded-md`}
                >
                  <MessageSquare className="w-3 h-3 text-foreground" />
                  <span className="text-xs font-bold text-foreground">{t("WhatsApp", "واتساب")}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
